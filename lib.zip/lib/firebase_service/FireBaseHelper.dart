import 'package:dijlah_store_ibtechiq/common/constant.dart';
import 'package:dijlah_store_ibtechiq/languages/language_constants.dart';
import 'package:dijlah_store_ibtechiq/model/products.dart';
import 'package:dijlah_store_ibtechiq/screens/detail_product.dart';
import 'package:dijlah_store_ibtechiq/screens/products.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import '../service/bLoC.dart';
class FireBaseHelper {
  FireBaseHelper._();
  factory FireBaseHelper() => _instance;
  static final FireBaseHelper _instance = FireBaseHelper._();
  final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
  //this fun for firebase Messaging
  Future<void> init(BuildContext context, BLoC bLoC) async {
    _firebaseMessaging.subscribeToTopic("dijlah");
    // For iOS request permission first.
    _firebaseMessaging.requestNotificationPermissions(
        const IosNotificationSettings(sound: true, badge: true, alert: true));
    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {
        print("onMessage: $message");
      },
      onLaunch: (Map<String, dynamic> message) async {
        String type = message['data']['type'];
        String typeId = message['data']['type_id'];
        String name = message['data']['type_name'];
        if (type == '1') {
          await getProduct(type).then((value) {
            if (value != null) {
              Product product = value;
              Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (BuildContext context) =>
                      DetailProduct(
                        bLoC: bLoC,
                        product: product,
                      ),
                ),
              );
            }
          });
        }
        else if(type == '0'){
         Navigator.push(context, PageTransition(type:PageTransitionType.fade, child:
                      Products(
                        bLoC: bLoC,
                        id: typeId,
                        title:name ==
                            null
                            ? getTranslated(context, "all_products_title")
                            : name,
                        getFrom: "category",
                      )));
        }
        else if(type == '2'){
         Navigator.push(context, PageTransition(type:PageTransitionType.fade, child:
                      Products(
                        bLoC: bLoC,
                        id: typeId,
                        title:name ==
                            null
                            ? getTranslated(context, "all_products_title")
                            : name,
                        getFrom: "brand",
                      )));
        }
        else if(type == '3' ){
         Navigator.push(context, PageTransition(type:PageTransitionType.fade, child:
                      Products(
                        bLoC: bLoC,
                        id: typeId,
                        title:name ==
                            null
                            ? getTranslated(context, "all_products_title")
                            : name,
                        getFrom: "shop",
                      )));
        }
        else{

        }
      },
      onResume: (Map<String, dynamic> message) async {
        String type = message['data']['type'];
        String typeId = message['data']['type_id'];
        String name = message['data']['type_name'];

        if (type == '1') {
          await getProduct(type).then((value) {
            if (value != null) {
              Product product = value;
              Navigator.push(
                context,
                MaterialPageRoute<void>(
                  builder: (BuildContext context) =>
                      DetailProduct(
                        bLoC: bLoC,
                        product: product,
                      ),
                ),
              );
            }
          });
        }
        else if(type == '0'){
         Navigator.push(context, PageTransition(type:PageTransitionType.fade, child:
                      Products(
                        bLoC: bLoC,
                        id: typeId,
                        title:name ==
                            null
                            ? getTranslated(context, "all_products_title")
                            : name,
                        getFrom: "category",
                      )));
        }
        else if(type == '2'){
         Navigator.push(context, PageTransition(type:PageTransitionType.fade, child:
                      Products(
                        bLoC: bLoC,
                        id: typeId,
                        title:name ==
                            null
                            ? getTranslated(context, "all_products_title")
                            : name,
                        getFrom: "brand",
                      )));
        }
        else if(type == '3' ){
          Navigator.push(context, PageTransition(type:PageTransitionType.fade, child:
                      Products(
                        bLoC: bLoC,
                        id: typeId,
                        title:name ==
                            null
                            ? getTranslated(context, "all_products_title")
                            : name,
                        getFrom: "shop",
                      )));
        }
        else{}
      }
    );
    _firebaseMessaging.onIosSettingsRegistered
        .listen((IosNotificationSettings settings) {});
  }
}
