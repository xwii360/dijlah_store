import 'dart:convert';

import 'package:dijlah_store_ibtechiq/screens/login_as_seller.dart';
import 'package:dijlah_store_ibtechiq/service/registration_api.dart';
import 'package:dijlah_store_ibtechiq/service/bLoC.dart';
import 'package:dijlah_store_ibtechiq/common/constant.dart';
import 'package:dijlah_store_ibtechiq/common/theme.dart';
import 'package:dijlah_store_ibtechiq/languages/language_constants.dart';
import 'package:dijlah_store_ibtechiq/screens/home.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart';
import 'package:page_transition/page_transition.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Login extends StatefulWidget {
  final BLoC bLoC;
  const Login({Key key, this.bLoC}) : super(key: key);
  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  TextEditingController phoneController = TextEditingController();
  TextEditingController smsCodeController = TextEditingController();
  String phoneNo, verificationId;
  bool codeSent = false;
  bool phonePage = true;
  final _formKey = new GlobalKey<FormState>();
  bool loading = false;
  var statusVer;
  @override
  void initState() {
    checkInternet(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 90,
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          getTranslated(context, "welcome"),
                          style: loginTitleStyle1,
                        ),
                        SizedBox(height: 5),
                        Text(
                          getTranslated(context, "continue_login"),
                          style: loginTitleStyle2,
                        ),
                      ],
                    ),
                    TextButton(
                        onPressed: () {
                          Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => LoginAsSeller(
                                        bLoC: widget.bLoC,
                                      )),
                              (route) => false);
                        },
                        child: Text(
                          getTranslated(context, "login_as_seller"),
                          style: loginTitleStyle3,
                        ))
                  ],
                ),
              ),
              Form(
                key: _formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    phonePage
                        ? Container(
                      child: Padding(
                        padding: EdgeInsets.only(
                            left: 15.0, right: 15.0, top: 20),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Text(
                               getTranslated(context, 'phone_number'),
                                textAlign: TextAlign.right,
                                textDirection: TextDirection.rtl,
                                style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                            Directionality(
                              textDirection: TextDirection.rtl,
                              child: TextFormField(
                                controller: phoneController,
                                autofocus: false,
                                keyboardType: TextInputType.phone,
                                validator: (value) {
                                  if (value.isEmpty) {
                                    return getTranslated(context, 'phone_number_required_filed');
                                  }
                                  return null;
                                },
                                inputFormatters: [
                                  LengthLimitingTextInputFormatter(10),
                                  WhitelistingTextInputFormatter(
                                      RegExp("[0-9]")),
                                ],
                                autocorrect: false,
                                textDirection: TextDirection.ltr,
                                textAlign: TextAlign.right,
                                decoration: InputDecoration(
                                  border: OutlineInputBorder(
                                    borderRadius: const BorderRadius.all(
                                      const Radius.circular(10.0),
                                    ),
                                    borderSide: BorderSide(
                                        color: Colors.grey, width: 0),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: const BorderRadius.all(
                                      const Radius.circular(10.0),
                                    ),
                                    borderSide: BorderSide(
                                        color: Colors.grey[800], width: 1.2),
                                  ),
                                  alignLabelWithHint: false,
                                  prefixIcon: Icon(
                                    Icons.phone_android,
                                    color: Colors.teal,
                                  ),
                                  labelText: getTranslated(context, "phone_number"),
                                  suffixText: "964+",
                                  labelStyle: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 13,
                                  ),
                                ),
                                onChanged: (val) {
                                  setState(() {
                                    this.phoneNo = val;
                                  });
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                        : Container(),
                    codeSent
                        ? WillPopScope(
                      onWillPop: () async {
                        smsCodeController.clear();
                        setState(() {
                          this.phonePage = true;
                          this.codeSent = false;
                        });
                      },
                      child: Container(
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: 15.0, right: 15.0, top: 20),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  getTranslated(context, 'pin_code'),
                                  textAlign: TextAlign.right,
                                  textDirection: TextDirection.rtl,
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Directionality(
                                textDirection: TextDirection.rtl,
                                child: TextFormField(
                                  controller: smsCodeController,
                                  autofocus: false,
                                  keyboardType: TextInputType.phone,
                                  validator: (value) {
                                    if (value.isEmpty) {
                                      return getTranslated(context, 'pin_code_required');
                                    }
                                    return null;
                                  },
                                  autocorrect: false,
                                  textDirection: TextDirection.ltr,
                                  textAlign: TextAlign.right,
                                  inputFormatters: [
                                    LengthLimitingTextInputFormatter(6),
                                    WhitelistingTextInputFormatter(
                                        RegExp("[0-9]")),
                                  ],
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(
                                        borderRadius:
                                        const BorderRadius.all(
                                          const Radius.circular(10.0),
                                        ),
                                        borderSide: BorderSide(
                                            color: Colors.grey, width: 0),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius:
                                        const BorderRadius.all(
                                          const Radius.circular(10.0),
                                        ),
                                        borderSide: BorderSide(
                                            color: Colors.teal[300],
                                            width: 1),
                                      ),
                                      alignLabelWithHint: false,
                                      suffixIcon: Icon(
                                        Icons.check_circle,
                                        color: Colors.teal,
                                      ),
                                      labelText: getTranslated(context, 'pin_code'),
                                      labelStyle: TextStyle(
                                        color: Colors.grey,
                                        fontSize: 13,
                                      )),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    )
                        : Container(),

                SizedBox(height: 30,),
                Center(
                  child: SizedBox(
                      width: MediaQuery.of(context).size.width / 1.1,
                      height: 48,
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10),
                          gradient: LinearGradient(
                            colors: [Color(0xff86f7b6), Color(0xff8fd3f1)],
                          ),
                        ),
                        child: RaisedButton(
                            color: Colors.transparent,
                              elevation: 0,

                              child: Center(
                                  child: codeSent
                                      ? Text(
                                    getTranslated(context, 'check'),
                                    style: TextStyle(
                                        fontSize: 20,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold
                                    ),
                                  )
                                      : Text(
                                    getTranslated(context, 'send'),
                                    style: TextStyle(
                                        fontSize: 20,
                                        color: Colors.white,
                                        fontWeight: FontWeight.bold
                                    ),
                                  )),
                              onPressed: () async {
                                if (_formKey.currentState.validate()) {
                                  SharedPreferences pref =
                                  await SharedPreferences.getInstance();
                                  pref.setString(
                                      "login_type", 'phone');
                                  FocusScope.of(context)
                                      .requestFocus(new FocusNode());
                                  if (codeSent) {
                                    if (smsCodeController.text.trim().length <
                                        6) {
                                      showTopFlash(context,"",getTranslated(context, 'pin_code_less_than'),false);
                                    } else if (smsCodeController.text
                                        .trim()
                                        .length >
                                        6) {
                                      showTopFlash(context,"",getTranslated(context, 'pin_code_more_than'),false);
                                    } else if (smsCodeController.text
                                        .trim()
                                        .length ==
                                        6) {
                                      try {
                                        final code =
                                        smsCodeController.text.trim();
                                        print(code);
                                        AuthCredential credential =
                                        PhoneAuthProvider.getCredential(
                                            verificationId: verificationId,
                                            smsCode: code);
                                        await FirebaseAuth.instance
                                            .signInWithCredential(credential);
                                        showTopFlash(context,"",getTranslated(context, 'login_successfully'),false);
                                        var userId = pref.getString("userId");
                                        await updatePhoneVerificationStatus(
                                            userId);
                                        Navigator.pushAndRemoveUntil(
                                            context,
                                            MaterialPageRoute(
                                                builder: (context) =>
                                                    HomeScreen(bLoC: widget.bLoC,)),
                                                (route) => false);
                                      } on PlatformException catch (err) {
                                        print(err);
                                        if (err.message ==
                                            "The SMS verification code used to create the phone auth credential is invalid. Please resend the verification code SMS and be sure to use the verification code provided by the user.") {
                                          showTopFlash(context,"",getTranslated(context, 'invalid_pin'),true);
                                        } else if (err.message.contains(
                                            'The sms code has expired')) {
                                          showTopFlash(context,"",getTranslated(context, 'expired_pin'),true);
                                        }
                                      } catch (error) {
                                        print(error);
                                        return error;
                                      }
                                    }
                                  } else {
                                    if (phoneNo.length < 10) {
                                      showTopFlash(context,"",getTranslated(context, 'phone_more_than'),true);
                                    } else if (phoneNo.startsWith("0")) {
                                      showTopFlash(context,"",getTranslated(context, 'remove_zero'),true);
                                    } else if (phoneNo.length > 10) {
                                      showTopFlash(context,"",getTranslated(context, 'phone_less_than'),true);
                                    } else if (phoneNo.length == 10) {
                                      continueLogin();
                                      confirmPhoneFromAppDialog();
                                    }
                                  }
                                }
                              }),
                      ))),
                    codeSent?  Center(
                      child: Padding(
                        padding: const EdgeInsets.only(top:18.0),
                        child: TextButton(onPressed: (){
                          setState(() {
                            phonePage=true;
                            codeSent=false;
                          });
                        }, child: Text(getTranslated(context, 'resend_pin'),style: TextStyle(fontSize: 12,color: Colors.black,fontWeight: FontWeight.bold),)),
                      ),
                    ):Container(),
                    SizedBox(
                      height: 30,
                    ),
                    Center(
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width / 1.1,
                        height: 48,
                        child: RaisedButton.icon(
                          color: Colors.white,
                          elevation: 0,
                          shape: shape1,
                          onPressed: () {
                            checkInternet(context).then((value) async {
                              if (value == 'ok') {
                                loginFaceBook(context, widget.bLoC);
                              }
                            });
                          },
                          icon: Icon(FontAwesomeIcons.facebookF),
                          label: Text(
                            getTranslated(context, "facebook_login"),
                            style: button2TextLogin,
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Center(
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width / 1.1,
                        height: 48,
                        child: RaisedButton.icon(
                          color: Colors.white,
                          elevation: 0,
                          shape: shape1,
                          onPressed: () {
                            checkInternet(context).then((value) async {
                              if (value == 'ok') {
                                loginWithGoogle(context, widget.bLoC);
                              }
                            });
                          },
                          icon: Icon(FontAwesomeIcons.google),
                          label: Padding(
                            padding:
                            const EdgeInsets.only(right: 2.0, left: 2.0),
                            child: Text(
                              getTranslated(context, "google_login"),
                              style: button2TextLogin,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    TextButton(
                        onPressed: () async {
                          SharedPreferences pref =
                          await SharedPreferences.getInstance();
                          pref.setString("skipLogin", "1");
                          Navigator.push(
                              context,
                              PageTransition(
                                  type: PageTransitionType.fade,
                                  child: HomeScreen(
                                    bLoC: widget.bLoC,
                                  )));
                        },
                        child: Center(
                          child: Padding(
                            padding: const EdgeInsets.only(top: 8.0),
                            child: Text(getTranslated(context, "skip_login"),
                                style: hintTextInput),
                          ),
                        )),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String getPhoneNumber(String input) {
    if (input.length >= 10) {
      String first = input.substring(0, 1);
      if (first == "0") input = input.substring(1);
      String nat = input.substring(0, 2);
      if (nat == "75" || nat == "77" || nat == "78" || nat == "79") {
        if (input.length == 10) return "+964" + input;
      }
    }
    return "";
  }

  Future<void> verifyPhone(phoneNo) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    continueLogin();
    final PhoneVerificationCompleted verificationCompleted =
        (AuthCredential authResult) async {
          continueLogin();
      FirebaseAuth.instance.signInWithCredential(authResult);
      var userId = pref.getString("userId");
      await updatePhoneVerificationStatus(userId);
      Navigator.pushAndRemoveUntil(
          context,
          MaterialPageRoute(builder: (context) => HomeScreen(bLoC: widget.bLoC,)),
              (route) => false);
    };
    final PhoneVerificationFailed verificationFailed =
        (AuthException authException) {
      print('${authException.message.toString()}');
    };
    final PhoneCodeSent codeSent = (String verId, [int forceResending]) async {
      this.verificationId = verId;
      final code = smsCodeController.text.trim();
      try {
        AuthCredential credential = PhoneAuthProvider.getCredential(
            verificationId: verId, smsCode: code);
        FirebaseAuth.instance.signInWithCredential(credential);
        setState(() {
          this.codeSent = true;
          this.phonePage = false;
        });
      } on PlatformException catch (err) {
        if (err.message.contains(
            "he SMS verification code used to create the phone auth credential is invalid")) {
          showTopFlash(context,"",getTranslated(context, 'invalid_pin'),true);
        } else if (err.message.contains('The sms code has expired')) {
          showTopFlash(context,"",getTranslated(context, 'expired_pin'),true);
        }
        print(err);
      } catch (error) {
      print(error.toString());
        return error;
      }
    };
    final PhoneCodeAutoRetrievalTimeout codeAutoRetrievalTimeout =
        (String verificationId) {
      this.verificationId = verificationId;
      print("Time out");
    };
    try {
      await FirebaseAuth.instance.verifyPhoneNumber(
          phoneNumber: getPhoneNumber(phoneNo),
          timeout: Duration(seconds: 60),
          verificationCompleted: verificationCompleted,
          verificationFailed: verificationFailed,
          codeSent: codeSent,
          codeAutoRetrievalTimeout: codeAutoRetrievalTimeout);
    } catch (error) {
      print(error);
      return error;
    }
  }

  continueLogin() async {
    String phone = getPhoneNumber(phoneNo);
    await loginWithPhone(phone);
  }

  Future<bool> confirmPhoneFromAppDialog() {
    return showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => AlertDialog(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              title: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                     getTranslated(context, 'are_you_sure_phone'),
                      style: TextStyle(fontSize: 18, color: Colors.black),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  Text(
                    "+964${phoneController.text.trim().toString()}",
                    style: TextStyle(fontSize: 17, color: Colors.teal),
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.center,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(top: 18.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: <Widget>[
                        RaisedButton(
                          color: Colors.grey[800],
                          child: Text(
                            getTranslated(context, 'no'),
                            style: TextStyle(
                                color: Colors.white,
                                fontSize: 15,
                                fontWeight: FontWeight.bold),
                            textAlign: TextAlign.center,
                          ),
                          onPressed: () {
                            Navigator.of(context).pop();
                          },
                        ),
                        RaisedButton(
                          color: Colors.teal[300],
                          child: Text(getTranslated(context, 'yes'),
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold)),
                          onPressed: () async {
                            SharedPreferences pref =
                                await SharedPreferences.getInstance();
                            var phone_ver = pref.getString("phone_ver");
                            print(phone_ver);
                            if (phone_ver == "1") {
                              Navigator.of(context).pop();
                              Navigator.pushAndRemoveUntil(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => HomeScreen(
                                            bLoC: widget.bLoC,
                                          )),
                                  (route) => false);
                            } else {
                              Navigator.of(context).pop();
                              verifyPhone(phoneNo);
                              setState(() {
                                this.codeSent = true;
                                this.phonePage = false;
                              });
                            }
                          },
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ));
  }
  Future<bool> updatePhoneVerificationStatus(String userId) async {
    String url = MAIN_URL + "auth/updatePhoneVerification";
    Map<String, dynamic> body = {'user_id': userId};
    Response response = await post(url, body: body);
    print(response.body);
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      print(data);
      var statusVer = data['status'];
      setState(() {
          this.statusVer = statusVer;
      });
      return true;
    }
    return false;
  }
}
