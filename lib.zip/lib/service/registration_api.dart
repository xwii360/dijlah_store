import 'dart:convert';
import 'package:dijlah_store_ibtechiq/common/constant.dart';
import 'package:dijlah_store_ibtechiq/languages/language_constants.dart';
import 'package:dijlah_store_ibtechiq/screens/home.dart';
import 'package:flutter/material.dart';
import 'package:flutter_facebook_login/flutter_facebook_login.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:http/http.dart';
import 'package:page_transition/page_transition.dart';
import 'package:shared_preferences/shared_preferences.dart';
Future<void> signUp(emailOrPhone,name,password) async {
  SharedPreferences pref = await SharedPreferences.getInstance();
  String url = MAIN_URL + "auth/signup";
  Response response = await post(Uri.encodeFull(url),
   headers: {
    "X-Requested-With" : "XMLHttpRequest",
   },
   body: {
    'email_or_phone':emailOrPhone,
    'name':name,
    'password':password,
     'register_by':"email"
  });
    var data = jsonDecode(response.body);
       print(response.body);
    var message = data['message'];
     var result = data['result'];
        pref.setString("messages", message);
        pref.setString("result", result.toString());
    if(result==true && message=="Registration Successful. Please verify and log in to your account.") {
      var accessToken = data['access_token'];
      var id = data['user']['id'].toString();
      print(id);
      var email = data['user']['email'];
      var name = data['user']['name'];
      print(name);
      var phone = data['user']['phone'];
      var country = data['user']['country'];
      var userType = data['user']['user_type'];
      pref.setString("access_token", accessToken);
      pref.setString("userId", id);
      pref.setString("email", email);
      pref.setString("name", name);
      pref.setString("phone", phone);
      pref.setString("country", country);
      pref.setString("user_type", userType);
    return true;
  }
    return false;
}
Future<void> login(String email, String password) async {
  String url = MAIN_URL + "auth/login";
  Map<String, String> body = {'email': email, 'password': password};
  Response response = await post(url, body: body, headers: {
    "X-Requested-With" : "XMLHttpRequest",
  },);
  print(response.body);
    SharedPreferences pref = await SharedPreferences.getInstance();
    var data = jsonDecode(response.body);
    print(data);
    var message = data['message'];
  var result = data['result'];
  pref.setString("message", message);
  pref.setString("result", result.toString());
    var user = data['user'];
         if( message=="Successfully logged in" && result==true) {
          pref.setString("user", user.toString());
          var accessToken = data['access_token'];
          var id = data['user']['id'].toString();
          var email = data['user']['email'];
          var name = data['user']['name'];
          var phone = data['user']['phone'];
          var country = data['user']['country'];
          var userType = data['user']['user_type'];
          pref.setString("access_token", accessToken);
          pref.setString("userId", id);
          pref.setString("email", email);
          pref.setString("name", name);
          pref.setString("phone", phone);
          pref.setString("country", country);
          pref.setString("user_type", userType);
        }
    return true;
}
Future<void> socialLogin(String Email, String Name) async {
  String url = MAIN_URL + "auth/social-login";
  Map<String, String> body = {'email': Email, 'name': Name};
  Response response = await post(url, body: body, headers: {
    "X-Requested-With" : "XMLHttpRequest",
  },);
  print(response.body);
    var data = jsonDecode(response.body);
    var accessToken = data['access_token'];
    var id = data['user']['id'].toString();
    var email = data['user']['email'];
    var name = data['user']['name'];
    var phone = data['user']['phone'];
    var country = data['user']['country'];
    var userType = data['user']['user_type'];
    SharedPreferences pref = await SharedPreferences.getInstance();
  pref.setString("access_token", accessToken);
  pref.setString("userId", id);
  pref.setString("email", email);
  pref.setString("name", name);
  pref.setString("phone", phone);
  pref.setString("country", country);
  pref.setString("user_type", userType);
  return true;
}


Future<String> signUpSeller(fullName,shopName,address,email,password,phone,selectType,selectCountry) async {
  String url = MAIN_URL + "shops/addShopAsNewUser";
  Map<String, String> body = {
    'name': fullName.toString(),
    'shop_name': shopName.toString(),
    'address':address.toString(),
    'email': email.toString(),
    'phone': phone.toString(),
    'state': selectCountry.toString(),
    'password': password.toString(),
    'verification_info': '[{"type":"text","label":"Your name","value":"${fullName.toString()}"},{"type":"text","label":"Shop name","value":"${shopName.toString()}"},{"type":"text","label":"Email","value":"${email.toString()}"},{"type":"text","label":"Phone Number","value":"${phone.toString()}"},{"type":"text","label":"vendor type","value":"${selectType.toString()}"},{"type":"text","label":"state","value":"${selectCountry.toString()}"}]'
  };
  Response response = await post(Uri.encodeFull(url),
      headers: {
        "Accept": "application/json",
      }, body: body);
  print(response.body);
  var data = jsonDecode(response.body);
  print(data);
  return data['message'];
}


Future<Null> loginFaceBook(context,bLoC) async {
   final FacebookLogin facebookSignIn = new FacebookLogin();
  SharedPreferences preferences = await SharedPreferences.getInstance();
   preferences.setString(
       "login_type", 'facebook');
  final FacebookLoginResult result = await facebookSignIn.logIn(['email']);
  switch (result.status) {
    case FacebookLoginStatus.loggedIn:
      final FacebookAccessToken accessToken = result.accessToken;
      showTopFlash(
          context, '', getTranslated(context, "login_successfully"), false);
      var graphResponse = await get(
          'https://graph.facebook.com/v2.12/me?fields=name,first_name,last_name,email&access_token=${accessToken.token}');
      var profile = json.decode(graphResponse.body);
      print(profile.toString());
      preferences.setString("name", profile['name']);
      preferences.setString("email", profile['email']);
      preferences.remove("skipLogin");
      await socialLogin(profile['email'], profile['name']);
      Navigator.push(context, PageTransition(type:PageTransitionType.fade, child:  HomeScreen(
        bLoC: bLoC,
      )));
      break;
    case FacebookLoginStatus.cancelledByUser:
      showTopFlash(context, '', "تم الغاء تسجيل الدخول", true);
      break;
    case FacebookLoginStatus.error:
      print(result.errorMessage);
      showTopFlash(
          context,
          '',
          "${result.errorMessage} ${getTranslated(context, "login_error")} ",
          true);
      break;
  }
}

Future<Null> loginWithGoogle(context,bLoC) async {
  final GoogleSignIn googleSignIn = GoogleSignIn(scopes: ['email']);
  SharedPreferences preferences = await SharedPreferences.getInstance();
  preferences.setString(
      "login_type", 'google');
  await googleSignIn.signIn().then((value) async {
    preferences.setString("name", googleSignIn.currentUser.displayName);
    preferences.setString("email", googleSignIn.currentUser.email);
    preferences.remove("skipLogin");
    showTopFlash(
        context, '', getTranslated(context, "login_successfully"), false);
    await socialLogin(googleSignIn.currentUser.email,
        googleSignIn.currentUser.displayName);
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) {
          return HomeScreen(
            bLoC: bLoC,
          );
        },
      ),
    );
  }).catchError((e) => print(e));
}


Future<void> loginWithPhone(String phoneNumber) async {
  String url = MAIN_URL + "auth/loginPhone";
  Map<String, String> body = {'phone': phoneNumber};
  Response response = await post(url, body: body, headers: {
    "X-Requested-With" : "XMLHttpRequest",
  },);

  var data = jsonDecode(response.body);
  print(data['user']);
  var accessToken = data['access_token'];
  var id = data['user']['id'].toString();
  var email = data['user']['email'];
  var name = data['user']['name'];
  var phone = data['user']['phone'];
  var country = data['user']['country'];
  var userType = data['user']['user_type'];
  var phoneVer = data['user']['phone_ver'].toString();

  SharedPreferences pref = await SharedPreferences.getInstance();
  pref.setString("access_token", accessToken);
  pref.setString("userId", id);
  pref.setString("email", email);
  pref.setString("name", name);
  pref.setString("phone", phone);
  pref.setString("country", country);
  pref.setString("user_type", userType);
  pref.setString("phone_ver", phoneVer);
  return true;
}
